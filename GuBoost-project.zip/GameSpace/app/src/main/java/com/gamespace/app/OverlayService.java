package com.gamespace.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

/** Menampilkan crosshair + tombol melayang di atas aplikasi/game lain. */
public class OverlayService extends Service {
    public static final String ACT_REFRESH = "refresh";
    public static final String ACT_DRAG = "drag";
    public static final String ACT_STOP = "stop";
    private static final String CHANNEL = "gamespace_overlay";

    public static boolean running = false;

    private WindowManager wm;
    private CrosshairView cross;
    private WindowManager.LayoutParams clp;
    private TextView bubble;
    private WindowManager.LayoutParams blp;
    private Button done;
    private boolean drag = false;
    private boolean crossShown = true;
    private float density;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;
        running = true;

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "GuBoost Overlay", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, OverlayService.class).setAction(ACT_STOP);
        PendingIntent psi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 2,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        nb.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("GuBoost aktif")
                .setContentText("Overlay crosshair berjalan")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Matikan", psi).build());
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACT_STOP.equals(a)) {
            Prefs.get(this).edit().putBoolean("overlay_on", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACT_DRAG.equals(a)) {
            Prefs.get(this).edit().putBoolean("cx_on", true).apply();
            sync();
            setDrag(true);
        } else {
            sync();
        }
        return START_STICKY;
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void sync() {
        SharedPreferences s = Prefs.get(this);

        // Crosshair
        boolean cxOn = s.getBoolean("cx_on", true);
        if (cxOn && cross == null) {
            cross = new CrosshairView(this);
            clp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            clp.gravity = Gravity.CENTER;
            clp.x = s.getInt("x", 0);
            clp.y = s.getInt("y", 0);
            wm.addView(cross, clp);
            cross.setVisibility(crossShown ? View.VISIBLE : View.INVISIBLE);
            cross.setOnTouchListener(new View.OnTouchListener() {
                float dx, dy;
                int sx, sy;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    if (!drag) return false;
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            dx = e.getRawX();
                            dy = e.getRawY();
                            sx = clp.x;
                            sy = clp.y;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            clp.x = sx + (int) (e.getRawX() - dx);
                            clp.y = sy + (int) (e.getRawY() - dy);
                            wm.updateViewLayout(cross, clp);
                            return true;
                        case MotionEvent.ACTION_UP:
                            Prefs.get(OverlayService.this).edit()
                                    .putInt("x", clp.x).putInt("y", clp.y).apply();
                            return true;
                    }
                    return false;
                }
            });
        } else if (!cxOn && cross != null) {
            if (drag) setDrag(false);
            safeRemove(cross);
            cross = null;
        }
        if (cross != null) {
            cross.reload();
            if (!drag) {
                clp.x = s.getInt("x", 0);
                clp.y = s.getInt("y", 0);
            }
            wm.updateViewLayout(cross, clp);
        }

        // Tombol melayang
        boolean bubbleOn = s.getBoolean("bubble_on", true);
        if (bubbleOn && bubble == null) {
            addBubble();
        } else if (!bubbleOn && bubble != null) {
            safeRemove(bubble);
            bubble = null;
        }
    }

    private void addBubble() {
        bubble = new TextView(this);
        bubble.setText("GS");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(13);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xCC00B050);
        bubble.setBackground(bg);
        int sz = (int) (44 * density);
        blp = new WindowManager.LayoutParams(sz, sz, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        blp.gravity = Gravity.TOP | Gravity.START;
        blp.x = 0;
        blp.y = (int) (160 * density);
        wm.addView(bubble, blp);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX();
                        dy = e.getRawY();
                        sx = blp.x;
                        sy = blp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > 12 || Math.abs(e.getRawY() - dy) > 12) moved = true;
                        if (moved) {
                            blp.x = sx + (int) (e.getRawX() - dx);
                            blp.y = sy + (int) (e.getRawY() - dy);
                            wm.updateViewLayout(bubble, blp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleCross();
                        return true;
                }
                return false;
            }
        });
    }

    private void toggleCross() {
        crossShown = !crossShown;
        if (cross != null) cross.setVisibility(crossShown ? View.VISIBLE : View.INVISIBLE);
        if (bubble != null && bubble.getBackground() instanceof GradientDrawable) {
            ((GradientDrawable) bubble.getBackground()).setColor(crossShown ? 0xCC00B050 : 0xCC777777);
        }
    }

    private void setDrag(boolean on) {
        if (cross == null) return;
        drag = on;
        cross.dragMode = on;
        crossShown = true;
        cross.setVisibility(View.VISIBLE);
        if (on) {
            clp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            done = new Button(this);
            done.setText("SELESAI - SIMPAN POSISI");
            WindowManager.LayoutParams dlp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            dlp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            dlp.y = (int) (80 * density);
            wm.addView(done, dlp);
            done.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setDrag(false);
                }
            });
        } else {
            clp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            if (done != null) {
                safeRemove(done);
                done = null;
            }
        }
        wm.updateViewLayout(cross, clp);
        cross.invalidate();
    }

    private void safeRemove(View v) {
        try {
            wm.removeView(v);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onDestroy() {
        if (cross != null) safeRemove(cross);
        if (bubble != null) safeRemove(bubble);
        if (done != null) safeRemove(done);
        cross = null;
        bubble = null;
        done = null;
        running = false;
        super.onDestroy();
    }
}
