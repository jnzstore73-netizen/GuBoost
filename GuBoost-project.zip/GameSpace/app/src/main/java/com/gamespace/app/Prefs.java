package com.gamespace.app;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private Prefs() {}

    public static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences("gamespace", Context.MODE_PRIVATE);
    }
}
