package com.gamespace.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.view.View;

import java.io.File;

public class CrosshairView extends View {
    public static final String[] SHAPES = {
            "Plus (+)", "Titik", "Lingkaran", "Lingkaran + Titik",
            "Silang (X)", "Plus + Titik", "Gambar sendiri (PNG/JPG)"
    };
    public static final int SHAPE_CUSTOM = 6;
    public static final String CUSTOM_FILE = "crosshair_custom.png";

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private int shape, color, sizePx, thickPx, gapPx, alpha;
    private boolean tint;
    private Bitmap bmp;
    public boolean dragMode = false;

    public CrosshairView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        reload();
    }

    public void reload() {
        SharedPreferences s = Prefs.get(getContext());
        shape = s.getInt("shape", 0);
        color = s.getInt("color", 0xFF00FF40);
        sizePx = (int) (s.getInt("size", 40) * d);
        thickPx = Math.max(1, (int) (s.getInt("thick", 2) * d));
        gapPx = (int) (s.getInt("gap", 4) * d);
        alpha = s.getInt("alpha", 255);
        tint = s.getBoolean("tint", false);
        bmp = null;
        if (shape == SHAPE_CUSTOM) {
            File f = new File(getContext().getFilesDir(), CUSTOM_FILE);
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                if (b != null) {
                    float sc = (float) sizePx / Math.max(b.getWidth(), b.getHeight());
                    bmp = Bitmap.createScaledBitmap(b,
                            Math.max(1, Math.round(b.getWidth() * sc)),
                            Math.max(1, Math.round(b.getHeight() * sc)), true);
                }
            }
        }
        requestLayout();
        invalidate();
    }

    private int pad() {
        return thickPx + (int) (6 * d);
    }

    @Override
    protected void onMeasure(int w, int h) {
        int s = sizePx + pad() * 2;
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f, r = sizePx / 2f;
        p.setColor(color);
        p.setAlpha(alpha);
        p.setStrokeWidth(thickPx);
        p.setStrokeCap(Paint.Cap.BUTT);

        switch (shape) {
            case 0: plus(c, cx, cy, r); break;
            case 1: dot(c, cx, cy, r); break;
            case 2: ring(c, cx, cy, r); break;
            case 3: ring(c, cx, cy, r); dot(c, cx, cy, r); break;
            case 4: cross(c, cx, cy, r); break;
            case 5: plus(c, cx, cy, r); dot(c, cx, cy, r); break;
            case SHAPE_CUSTOM:
                if (bmp != null) {
                    Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                    bp.setAlpha(alpha);
                    if (tint) bp.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                    c.drawBitmap(bmp, cx - bmp.getWidth() / 2f, cy - bmp.getHeight() / 2f, bp);
                } else {
                    plus(c, cx, cy, r);
                }
                break;
            default: plus(c, cx, cy, r);
        }

        if (dragMode) {
            Paint b = new Paint(Paint.ANTI_ALIAS_FLAG);
            b.setStyle(Paint.Style.STROKE);
            b.setColor(Color.WHITE);
            b.setStrokeWidth(d);
            c.drawRect(d, d, getWidth() - d, getHeight() - d, b);
        }
    }

    private void plus(Canvas c, float cx, float cy, float r) {
        float g = gapPx;
        p.setStyle(Paint.Style.STROKE);
        c.drawLine(cx - r, cy, cx - g, cy, p);
        c.drawLine(cx + g, cy, cx + r, cy, p);
        c.drawLine(cx, cy - r, cx, cy - g, p);
        c.drawLine(cx, cy + g, cx, cy + r, p);
    }

    private void cross(Canvas c, float cx, float cy, float r) {
        float a = r * 0.707f, g = gapPx * 0.707f;
        p.setStyle(Paint.Style.STROKE);
        c.drawLine(cx - a, cy - a, cx - g, cy - g, p);
        c.drawLine(cx + g, cy + g, cx + a, cy + a, p);
        c.drawLine(cx + a, cy - a, cx + g, cy - g, p);
        c.drawLine(cx - g, cy + g, cx - a, cy + a, p);
    }

    private void ring(Canvas c, float cx, float cy, float r) {
        p.setStyle(Paint.Style.STROKE);
        c.drawCircle(cx, cy, r, p);
    }

    private void dot(Canvas c, float cx, float cy, float r) {
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, Math.max(thickPx * 1.2f, r * 0.1f), p);
    }
}
