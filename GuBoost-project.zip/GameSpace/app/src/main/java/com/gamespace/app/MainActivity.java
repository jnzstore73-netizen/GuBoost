package com.gamespace.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.IntConsumer;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQ_SHIZUKU = 100;
    private static final int REQ_IMAGE = 200;
    private static final int REQ_NOTIF = 300;

    private SharedPreferences sp;
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private LinearLayout root, gamesBox;
    private TextView tvShizuku;
    private View colorPreview;
    private Switch swSens, swFps;
    private SeekBar sbR, sbG, sbB;

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> ui.post(this::updateShizukuStatus);
    private final Shizuku.OnBinderReceivedListener binderListener =
            () -> ui.post(this::updateShizukuStatus);
    private final Shizuku.OnBinderDeadListener deadListener =
            () -> ui.post(this::updateShizukuStatus);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Prefs.get(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF10151C);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(40));
        sv.addView(root);
        setContentView(sv);

        buildUi();

        try {
            Shizuku.addBinderReceivedListenerSticky(binderListener);
            Shizuku.addBinderDeadListener(deadListener);
            Shizuku.addRequestPermissionResultListener(permListener);
        } catch (Throwable ignored) {
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateShizukuStatus();
        refreshGames();
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderListener);
            Shizuku.removeBinderDeadListener(deadListener);
            Shizuku.removeRequestPermissionResultListener(permListener);
        } catch (Throwable ignored) {
        }
        ex.shutdown();
        super.onDestroy();
    }

    // ------------------------------------------------------------ UI

    private void buildUi() {
        TextView t = new TextView(this);
        t.setText("GuBoost");
        t.setTextColor(0xFF00E676);
        t.setTextSize(26);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(t);

        // --- Shizuku
        title("1. Akses Shizuku");
        tvShizuku = text("...");
        Button bShz = button("Beri izin Shizuku", v -> requestShizuku());
        Button bOpenShz = button("Buka aplikasi Shizuku", v -> openShizukuApp());

        // --- Overlay
        title("2. Tampil di atas aplikasi");
        Button bPerm = button("Izinkan \"Tampilkan di atas aplikasi lain\"", v -> {
            if (!Settings.canDrawOverlays(this)) openOverlaySettings();
            else toast("Izin overlay sudah aktif");
        });
        sw("Aktifkan overlay (crosshair + tombol GS)", sp.getBoolean("overlay_on", false), (cb, on) -> {
            if (on && !Settings.canDrawOverlays(this)) {
                cb.setChecked(false);
                openOverlaySettings();
                return;
            }
            sp.edit().putBoolean("overlay_on", on).apply();
            if (on) startOverlay(null);
            else stopService(new Intent(this, OverlayService.class));
        });
        sw("Tombol melayang GS (ketuk = sembunyi/tampil crosshair)",
                sp.getBoolean("bubble_on", true), (cb, on) -> {
                    sp.edit().putBoolean("bubble_on", on).apply();
                    refreshOverlay();
                });

        // --- Boost
        title("3. Boost (lewat Shizuku)");
        swSens = sw("Sensitivity Pro (layar licin & responsif)", sp.getBoolean("sens_on", false), (cb, on) -> {
            if (on && !Shell.ready()) {
                cb.setChecked(false);
                toast("Shizuku belum siap. Jalankan Shizuku & beri izin dulu.");
                return;
            }
            sp.edit().putBoolean("sens_on", on).apply();
            final int lvl = sp.getInt("sens_level", 12);
            ex.execute(() -> {
                if (on) Boost.applySensitivity(this, lvl);
                else Boost.resetSensitivity(this);
                ui.post(() -> toast(on ? "Sensitivity Pro aktif" : "Sensitivity dikembalikan"));
            });
        });
        seek("Level kecepatan sentuh/pointer", 0, 14, sp.getInt("sens_level", 12), v -> {
            sp.edit().putInt("sens_level", v).apply();
            if (sp.getBoolean("sens_on", false) && Shell.ready()) {
                ex.execute(() -> Boost.applySensitivity(this, v));
            }
        });

        swFps = sw("Up FPS (naikkan refresh rate)", sp.getBoolean("fps_on", false), (cb, on) -> {
            if (on && !Shell.ready()) {
                cb.setChecked(false);
                toast("Shizuku belum siap. Jalankan Shizuku & beri izin dulu.");
                return;
            }
            sp.edit().putBoolean("fps_on", on).apply();
            final int hz = sp.getInt("fps_hz", 120);
            ex.execute(() -> {
                if (on) Boost.applyFps(this, hz);
                else Boost.resetFps(this);
                ui.post(() -> toast(on ? "Up FPS: " + hz + " Hz" : "Refresh rate dikembalikan"));
            });
        });
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        final int[] hzs = {60, 90, 120, 144};
        int cur = sp.getInt("fps_hz", 120);
        for (int hz : hzs) {
            RadioButton rb = new RadioButton(this);
            rb.setText(hz + " Hz");
            rb.setTextColor(Color.WHITE);
            rb.setId(1000 + hz);
            rg.addView(rb);
            if (hz == cur) rb.setChecked(true);
        }
        rg.setOnCheckedChangeListener((g, id) -> {
            int hz = id - 1000;
            sp.edit().putInt("fps_hz", hz).apply();
            if (sp.getBoolean("fps_on", false) && Shell.ready()) {
                ex.execute(() -> Boost.applyFps(this, hz));
            }
        });
        root.addView(rg);
        text("Catatan: hanya menaikkan batas refresh rate layar. FPS game tetap dibatasi game & hardware HP.");

        // --- Crosshair
        title("4. Crosshair");
        sw("Tampilkan crosshair", sp.getBoolean("cx_on", true), (cb, on) -> {
            sp.edit().putBoolean("cx_on", on).apply();
            refreshOverlay();
        });

        Spinner sh = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, CrosshairView.SHAPES);
        sh.setAdapter(ad);
        sh.setSelection(sp.getInt("shape", 0));
        sh.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;

            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (first) {
                    first = false;
                    return;
                }
                sp.edit().putInt("shape", pos).apply();
                if (pos == CrosshairView.SHAPE_CUSTOM
                        && !new File(getFilesDir(), CrosshairView.CUSTOM_FILE).exists()) {
                    pickImage();
                }
                refreshOverlay();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });
        root.addView(label("Bentuk"));
        root.addView(sh);

        button("Pilih gambar crosshair (PNG/JPG)", v -> pickImage());
        sw("Warnai gambar dengan warna crosshair", sp.getBoolean("tint", false), (cb, on) -> {
            sp.edit().putBoolean("tint", on).apply();
            refreshOverlay();
        });

        root.addView(label("Warna"));
        colorPreview = new View(this);
        root.addView(colorPreview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));
        int col = sp.getInt("color", 0xFF00FF40);
        sbR = colorSeek("Merah", Color.red(col));
        sbG = colorSeek("Hijau", Color.green(col));
        sbB = colorSeek("Biru", Color.blue(col));
        updateColorPreview();

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        int[] pc = {0xFFFF1744, 0xFF00FF40, 0xFF00E5FF, 0xFFFFEA00, 0xFFFFFFFF, 0xFFFF00FF};
        for (int c : pc) {
            View sw = new View(this);
            sw.setBackgroundColor(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
            lp.setMargins(dp(4), dp(8), dp(4), dp(8));
            sw.setOnClickListener(v -> {
                sbR.setProgress(Color.red(c));
                sbG.setProgress(Color.green(c));
                sbB.setProgress(Color.blue(c));
            });
            presets.addView(sw, lp);
        }
        root.addView(presets);

        seek("Ukuran (dp)", 6, 200, sp.getInt("size", 40), v -> saveRefresh("size", v));
        seek("Ketebalan", 1, 12, sp.getInt("thick", 2), v -> saveRefresh("thick", v));
        seek("Celah tengah", 0, 40, sp.getInt("gap", 4), v -> saveRefresh("gap", v));
        seek("Transparansi", 20, 255, sp.getInt("alpha", 255), v -> saveRefresh("alpha", v));

        int w = getResources().getDisplayMetrics().widthPixels / 2;
        int h = getResources().getDisplayMetrics().heightPixels / 2;
        seek("Posisi X (geser kiri/kanan)", -w, w, sp.getInt("x", 0), v -> saveRefresh("x", v));
        seek("Posisi Y (geser atas/bawah)", -h, h, sp.getInt("y", 0), v -> saveRefresh("y", v));
        button("Geser crosshair dengan jari", v -> {
            if (!Settings.canDrawOverlays(this)) {
                openOverlaySettings();
                return;
            }
            sp.edit().putBoolean("overlay_on", true).apply();
            startOverlay(OverlayService.ACT_DRAG);
            moveTaskToBack(true);
        });
        button("Reset posisi ke tengah", v -> {
            sp.edit().putInt("x", 0).putInt("y", 0).apply();
            refreshOverlay();
            toast("Posisi direset (buka ulang halaman untuk menyegarkan slider)");
        });

        // --- Game
        title("5. Game saya");
        button("+ Tambah game", v -> pickGame());
        gamesBox = new LinearLayout(this);
        gamesBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(gamesBox);
        text("Ketuk game untuk membuka dengan overlay aktif. Tahan lama untuk menghapus dari daftar.");
    }

    // ------------------------------------------------------------ helper UI

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFFB0BEC5);
        t.setTextSize(13);
        t.setPadding(0, dp(4), 0, dp(4));
        root.addView(t);
        return t;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private void title(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFF00E676);
        t.setTextSize(17);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(24), 0, dp(4));
        root.addView(t);
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        root.addView(b);
        return b;
    }

    private interface CheckCb {
        void on(CompoundButton cb, boolean checked);
    }

    private Switch sw(String s, boolean init, CheckCb cb) {
        Switch sw = new Switch(this);
        sw.setText(s);
        sw.setTextColor(Color.WHITE);
        sw.setChecked(init);
        sw.setPadding(0, dp(8), 0, dp(8));
        sw.setOnCheckedChangeListener((b, c) -> cb.on(b, c));
        root.addView(sw);
        return sw;
    }

    private SeekBar seek(String s, int min, int max, int init, IntConsumer cb) {
        final TextView lb = label(s + ": " + init);
        root.addView(lb);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(init - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) {
                lb.setText(s + ": " + (p + min));
                if (fromUser) cb.accept(p + min);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        root.addView(sb);
        return sb;
    }

    private SeekBar colorSeek(String name, int init) {
        final TextView lb = label(name + ": " + init);
        root.addView(lb);
        SeekBar sb = new SeekBar(this);
        sb.setMax(255);
        sb.setProgress(init);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) {
                lb.setText(name + ": " + p);
                if (sbR == null || sbG == null || sbB == null) return;
                int c = Color.rgb(sbR.getProgress(), sbG.getProgress(), sbB.getProgress());
                sp.edit().putInt("color", c).apply();
                updateColorPreview();
                refreshOverlay();
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        root.addView(sb);
        return sb;
    }

    private void updateColorPreview() {
        if (colorPreview != null && sbR != null && sbG != null && sbB != null) {
            colorPreview.setBackgroundColor(Color.rgb(sbR.getProgress(), sbG.getProgress(), sbB.getProgress()));
        }
    }

    private void saveRefresh(String key, int v) {
        sp.edit().putInt(key, v).apply();
        refreshOverlay();
    }

    // ------------------------------------------------------------ Shizuku

    private void updateShizukuStatus() {
        String s;
        if (!Shell.binderAlive()) {
            s = "Status: Shizuku belum berjalan. Buka aplikasi Shizuku lalu Start (via Wireless debugging / ADB / root).";
        } else if (Shell.ready()) {
            s = "Status: TERHUBUNG. Fitur Sensitivity Pro & Up FPS siap dipakai.";
        } else {
            s = "Status: Shizuku berjalan, tetapi izin belum diberikan. Ketuk \"Beri izin Shizuku\".";
        }
        if (tvShizuku != null) tvShizuku.setText(s);
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku belum berjalan");
                openShizukuApp();
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Izin sudah diberikan");
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Izin ditolak permanen. Aktifkan manual di aplikasi Shizuku.");
                openShizukuApp();
            } else {
                Shizuku.requestPermission(REQ_SHIZUKU);
            }
        } catch (Throwable t) {
            toast("Shizuku tidak terpasang");
        }
        updateShizukuStatus();
    }

    private void openShizukuApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
        if (i != null) {
            startActivity(i);
        } else {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://github.com/RikkaApps/Shizuku/releases")));
        }
    }

    // ------------------------------------------------------------ Overlay

    private void openOverlaySettings() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    private void startOverlay(String action) {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            return;
        }
        Intent i = new Intent(this, OverlayService.class);
        if (action != null) i.setAction(action);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void refreshOverlay() {
        if (OverlayService.running) {
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACT_REFRESH));
        }
    }

    // ------------------------------------------------------------ Gambar crosshair

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMAGE || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri u = data.getData();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int ss = 1;
            while (o.outWidth / ss > 1024 || o.outHeight / ss > 1024) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                bm = BitmapFactory.decodeStream(in, null, o2);
            }
            if (bm == null) throw new Exception("gambar tidak valid");
            try (FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), CrosshairView.CUSTOM_FILE))) {
                bm.compress(Bitmap.CompressFormat.PNG, 100, fo);
            }
            sp.edit().putInt("shape", CrosshairView.SHAPE_CUSTOM).apply();
            refreshOverlay();
            toast("Gambar crosshair dipakai");
        } catch (Throwable t) {
            toast("Gagal memuat gambar: " + t.getMessage());
        }
    }

    // ------------------------------------------------------------ Game

    private List<ResolveInfo> launchables() {
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> l = getPackageManager().queryIntentActivities(main, 0);
        final PackageManager pm = getPackageManager();
        Collections.sort(l, (a, c) -> a.loadLabel(pm).toString()
                .compareToIgnoreCase(c.loadLabel(pm).toString()));
        return l;
    }

    private void pickGame() {
        final List<ResolveInfo> all = new ArrayList<>();
        for (ResolveInfo r : launchables()) {
            if (!r.activityInfo.packageName.equals(getPackageName())) all.add(r);
        }
        final String[] names = new String[all.size()];
        for (int i = 0; i < names.length; i++) names[i] = all.get(i).loadLabel(getPackageManager()).toString();
        new AlertDialog.Builder(this)
                .setTitle("Pilih game / aplikasi")
                .setItems(names, (d, which) -> {
                    Set<String> s = new HashSet<>(sp.getStringSet("games", new HashSet<>()));
                    s.add(all.get(which).activityInfo.packageName);
                    sp.edit().putStringSet("games", s).apply();
                    refreshGames();
                })
                .show();
    }

    private void refreshGames() {
        if (gamesBox == null) return;
        gamesBox.removeAllViews();
        PackageManager pm = getPackageManager();
        for (final String pkg : new ArrayList<>(sp.getStringSet("games", new HashSet<>()))) {
            String label;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                label = pm.getApplicationLabel(ai).toString();
            } catch (PackageManager.NameNotFoundException e) {
                continue;
            }
            TextView t = new TextView(this);
            t.setText("▶  " + label);
            t.setTextColor(Color.WHITE);
            t.setTextSize(16);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setBackgroundColor(0xFF1E2833);
            t.setPadding(dp(16), dp(14), dp(16), dp(14));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(4), 0, dp(4));
            t.setOnClickListener(v -> launchGame(pkg));
            t.setOnLongClickListener(v -> {
                Set<String> s = new HashSet<>(sp.getStringSet("games", new HashSet<>()));
                s.remove(pkg);
                sp.edit().putStringSet("games", s).apply();
                refreshGames();
                return true;
            });
            gamesBox.addView(t, lp);
        }
    }

    private void launchGame(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            toast("Tidak bisa membuka aplikasi");
            return;
        }
        if (Settings.canDrawOverlays(this)) {
            sp.edit().putBoolean("overlay_on", true).apply();
            startOverlay(null);
        } else {
            toast("Izin overlay belum aktif, crosshair tidak akan tampil");
        }
        startActivity(i);
    }
}
