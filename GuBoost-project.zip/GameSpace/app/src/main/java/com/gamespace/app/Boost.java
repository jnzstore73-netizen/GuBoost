package com.gamespace.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Fitur yang butuh akses Shizuku: Up FPS dan Sensitivity Pro.
 * Nilai asli setiap setting disimpan dulu, lalu dikembalikan saat fitur dimatikan.
 */
public final class Boost {
    private Boost() {}

    // namespace, key
    private static final String[][] FPS_KEYS = {
            {"system", "min_refresh_rate"},
            {"system", "peak_refresh_rate"},
            {"system", "user_refresh_rate"},
            {"system", "miui_refresh_rate"},
            {"secure", "refresh_rate_mode"},
    };

    private static final String[][] SENS_KEYS = {
            {"system", "pointer_speed"},
            {"secure", "long_press_timeout"},
            {"secure", "multi_press_timeout"},
            {"global", "window_animation_scale"},
            {"global", "transition_animation_scale"},
            {"global", "animator_duration_scale"},
    };

    private static String k(String ns, String key) {
        return "orig_" + ns + "_" + key;
    }

    private static void saveOriginal(SharedPreferences sp, String ns, String key) {
        if (sp.contains(k(ns, key))) return;
        String v = Shell.run("settings get " + ns + " " + key).trim();
        sp.edit().putString(k(ns, key), v).apply();
    }

    private static void put(SharedPreferences sp, String ns, String key, String value) {
        saveOriginal(sp, ns, key);
        Shell.run("settings put " + ns + " " + key + " " + value);
    }

    private static void restore(SharedPreferences sp, String[][] keys) {
        for (String[] e : keys) {
            String saved = sp.getString(k(e[0], e[1]), null);
            if (saved == null) continue;
            if (saved.isEmpty() || saved.equals("null") || saved.startsWith("ERR")) {
                Shell.run("settings delete " + e[0] + " " + e[1]);
            } else {
                Shell.run("settings put " + e[0] + " " + e[1] + " " + saved);
            }
            sp.edit().remove(k(e[0], e[1])).apply();
        }
    }

    /** hz: 90 / 120 / 144 dst. Menaikkan batas refresh rate layar (bukan melampaui batas hardware). */
    public static void applyFps(Context c, int hz) {
        SharedPreferences sp = Prefs.get(c);
        String v = hz + ".0";
        put(sp, "system", "min_refresh_rate", v);
        put(sp, "system", "peak_refresh_rate", v);
        put(sp, "system", "user_refresh_rate", String.valueOf(hz));
        put(sp, "system", "miui_refresh_rate", String.valueOf(hz));
        put(sp, "secure", "refresh_rate_mode", "2");
    }

    public static void resetFps(Context c) {
        restore(Prefs.get(c), FPS_KEYS);
    }

    /** level 0..14 -> pointer_speed -7..7. */
    public static void applySensitivity(Context c, int level) {
        SharedPreferences sp = Prefs.get(c);
        put(sp, "system", "pointer_speed", String.valueOf(level - 7));
        put(sp, "secure", "long_press_timeout", "250");
        put(sp, "secure", "multi_press_timeout", "200");
        put(sp, "global", "window_animation_scale", "0.5");
        put(sp, "global", "transition_animation_scale", "0.5");
        put(sp, "global", "animator_duration_scale", "0.5");
    }

    public static void resetSensitivity(Context c) {
        restore(Prefs.get(c), SENS_KEYS);
    }
}
