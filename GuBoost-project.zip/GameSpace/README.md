# GuBoost (Game Up Boost)

Fitur: Shizuku (Sensitivity Pro, Up FPS), overlay "tampil di atas aplikasi" dengan crosshair
(bentuk, warna, ukuran, ketebalan, celah, transparansi, posisi + geser jari, gambar PNG/JPG sendiri),
tombol melayang GS, dan daftar game.

## Cara build APK
**A. GitHub Actions (tanpa Android Studio)**
1. Buat repo GitHub, upload seluruh isi folder ini.
2. Tab Actions -> "Build APK" -> tunggu selesai -> unduh artifact `GuBoost-APK`.

**B. Android Studio**: File -> Open folder ini -> Build -> Build APK(s).

## Cara pakai
1. Pasang & jalankan Shizuku (Wireless debugging atau root), buka GuBoost (Game Up Boost), ketuk "Beri izin Shizuku".
2. Beri izin "Tampilkan di atas aplikasi lain", aktifkan overlay.
3. Tambah game, ketuk untuk membuka. Crosshair tampil di atas game.
